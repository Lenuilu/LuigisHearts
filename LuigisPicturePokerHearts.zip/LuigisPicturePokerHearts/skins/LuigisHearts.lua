local skin = {
    name = "Luigi's Picture Poker Hearts",
    suit = "h",
    texture = "luigipicturepokerhearts.png",
}
return skin